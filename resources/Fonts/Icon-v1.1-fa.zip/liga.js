/* A polyfill for browsers that don't support ligatures. */
/* The script tag referring to this file must be placed before the ending body tag. */

/* To provide support for elements dynamically added, this script adds
   method 'icomoonLiga' to the window object. You can pass element references to this method.
*/
(function () {
    'use strict';
    function supportsProperty(p) {
        var prefixes = ['Webkit', 'Moz', 'O', 'ms'],
            i,
            div = document.createElement('div'),
            ret = p in div.style;
        if (!ret) {
            p = p.charAt(0).toUpperCase() + p.substr(1);
            for (i = 0; i < prefixes.length; i += 1) {
                ret = prefixes[i] + p in div.style;
                if (ret) {
                    break;
                }
            }
        }
        return ret;
    }
    var icons;
    if (!supportsProperty('fontFeatureSettings')) {
        icons = {
            'search': '&#xf002;',
            'th-large': '&#xf009;',
            'close': '&#xf00d;',
            'remove': '&#xf00d;',
            'cog': '&#xf013;',
            'gear': '&#xf013;',
            'tag': '&#xf02b;',
            'book': '&#xf02d;',
            'image': '&#xf03e;',
            'photo': '&#xf03e;',
            'folder': '&#xf07b;',
            'folder-open': '&#xf07c;',
            'bar-chart': '&#xf080;',
            'bar-chart-o': '&#xf080;',
            'square-o': '&#xf096;',
            'chain': '&#xf0c1;',
            'link': '&#xf0c1;',
            'square': '&#xf0c8;',
            'bars': '&#xf0c9;',
            'navicon': '&#xf0c9;',
            'table': '&#xf0ce;',
            'caret-down': '&#xf0d7;',
            'caret-up': '&#xf0d8;',
            'caret-left': '&#xf0d9;',
            'caret-right': '&#xf0da;',
            'sitemap': '&#xf0e8;',
            'circle-o': '&#xf10c;',
            'circle': '&#xf111;',
            'folder-o': '&#xf114;',
            'folder-open-o': '&#xf115;',
            'code': '&#xf121;',
            'info': '&#xf129;',
            'puzzle-piece': '&#xf12e;',
            'git-square': '&#xf1d2;',
            'git': '&#xf1d3;',
            'share-alt': '&#xf1e0;',
            'share-alt-square': '&#xf1e1;',
            'area-chart': '&#xf1fe;',
            'pie-chart': '&#xf200;',
            'toggle-off': '&#xf204;',
            'toggle-on': '&#xf205;',
            'map-o': '&#xf278;',
            'map': '&#xf279;',
            'markdown': '&#xe904;',
          '0': 0
        };
        delete icons['0'];
        window.icomoonLiga = function (els) {
            var classes,
                el,
                i,
                innerHTML,
                key;
            els = els || document.getElementsByTagName('*');
            if (!els.length) {
                els = [els];
            }
            for (i = 0; ; i += 1) {
                el = els[i];
                if (!el) {
                    break;
                }
                classes = el.className;
                if (/icomoon-liga/.test(classes)) {
                    innerHTML = el.innerHTML;
                    if (innerHTML && innerHTML.length > 1) {
                        for (key in icons) {
                            if (icons.hasOwnProperty(key)) {
                                innerHTML = innerHTML.replace(new RegExp(key, 'g'), icons[key]);
                            }
                        }
                        el.innerHTML = innerHTML;
                    }
                }
            }
        };
        window.icomoonLiga();
    }
}());
